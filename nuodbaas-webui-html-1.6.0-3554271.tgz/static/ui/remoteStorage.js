// (C) Copyright 2026 Dassault Systemes SE.  All Rights Reserved.
function getRootDomain(url) {
  const parts = url.toLowerCase().split(".");
  if (parts.length <= 2) return url;
  return parts.slice(-2).join(".");
}

function isSameDomain(domain) {
  const currentDomain = getRootDomain(window.location.host);
  const remoteDomain = getRootDomain(domain) || domain;
  return remoteDomain && currentDomain === remoteDomain;
}

function handleGetRequest(event) {
  const { transactionId, key } = event.data;
  const storedValue = localStorage.getItem(key);
  event.source?.postMessage({
    transactionId,
    action: "remoteStorageGetResponse",
    data: storedValue,
  });
}

function handleSetRequest(event) {
  const { transactionId, key, value } = event.data;

  if (value === null) {
    localStorage.removeItem(key);
  } else {
    localStorage.setItem(key, value);
  }
  event.source?.postMessage({
    transactionId,
    action: "remoteStorageSetResponse",
    data: "success",
  });
}

function handleEvents(event) {
  if (!event.source?.postMessage) {
    return;
  }

  if (!isSameDomain(new URL(event.origin).host)) {
    return;
  }

  if (!event.data?.action) {
    return;
  }

  switch (event.data.action) {
    case "remoteStorageGet":
      handleGetRequest(event);
      break;
    case "remoteStorageSet":
      handleSetRequest(event);
      break;
  }
}

window.addEventListener("message", handleEvents);
